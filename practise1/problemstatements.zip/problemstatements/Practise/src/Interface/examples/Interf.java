package Interface.examples;

public interface Interf {

}
