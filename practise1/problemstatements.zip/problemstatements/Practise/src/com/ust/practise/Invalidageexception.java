package com.ust.practise;

public class Invalidageexception extends RuntimeException{

    public Invalidageexception(String message) {
        super(message);
    }

    public static void main(String[] args) {

    }
}
