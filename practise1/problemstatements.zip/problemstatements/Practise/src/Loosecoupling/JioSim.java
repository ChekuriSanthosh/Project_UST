package Loosecoupling;

public class JioSim implements Sim {
    public void browse(){
        System.out.println("Browsing with Jio");
    }

    public void call(){
        System.out.println("Calling with Jio");
    }
}
