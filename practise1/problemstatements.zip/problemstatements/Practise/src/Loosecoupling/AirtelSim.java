package Loosecoupling;

public class AirtelSim implements Sim{

    public void browse(){
        System.out.println("Browsing with Airtel");
    }

    public void call(){
        System.out.println("Calling with Airtel");
    }
}
