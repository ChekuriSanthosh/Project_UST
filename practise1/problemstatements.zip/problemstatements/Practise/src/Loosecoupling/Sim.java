package Loosecoupling;

public interface Sim {
    public void browse();
    public void call();

}
