//package Collections;
//
//import jdk.incubator.vector.VectorOperators;
//
//interface MathOperation{
//    int Calculate(int a,int b);
//}
//
//
////class Calculate{
////    int operation(int a, int b, Operator operator){
////        return
////    }
////}
//
//
//
////class MyPrint implements Printer1{
////    public void print(){
////        System.out.println("Hello UST");
////    }
////
////}
//
//
//
//public class lambdaexpression {
//    public static void main(String[] args) {
////        MathOperation obj=new MathOperation(){
////            public void print(){
////                System.out.println("UST GLOBAL");
////            }
////        };
////        Printer1 obj1=()-> System.out.println("Santhosh");
////        obj.print();
////        obj1.print();
//    }
//}
