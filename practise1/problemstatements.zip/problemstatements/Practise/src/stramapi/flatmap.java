package stramapi;

public class flatmap {

}
