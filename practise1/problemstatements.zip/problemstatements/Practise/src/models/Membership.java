package models;

public enum Membership {
    NORMAL, PREMIUM;
}
