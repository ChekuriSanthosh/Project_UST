package models;

public enum Status {
    PENDING, PROCESSING, COMPLETED;
}
