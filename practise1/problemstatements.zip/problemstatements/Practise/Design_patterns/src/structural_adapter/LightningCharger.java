package structural_adapter;

public interface LightningCharger {
    public void chargeWithLightning();
}
