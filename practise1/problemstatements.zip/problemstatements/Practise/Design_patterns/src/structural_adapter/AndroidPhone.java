package structural_adapter;

public class AndroidPhone {

    public void charge(){
        System.out.println("Charging phone with a Type-c Charger");
    }
}
