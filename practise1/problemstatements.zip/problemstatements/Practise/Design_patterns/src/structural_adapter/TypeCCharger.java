package structural_adapter;

public interface TypeCCharger {
    public void chargeWithTypeC();
}
