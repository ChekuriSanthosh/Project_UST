package structural_adapter;

public class IPhone {
    public void charge(){
        System.out.println("Charging phone with a Lightning Charger");
    }
}
