package com.ust.task.service;
import com.ust.task.model.Employee;

public interface Employeemanagement {
    public default void registerEmployee(Employee employee){

    }
    public default void removeEmployee(int id){

    }
}
