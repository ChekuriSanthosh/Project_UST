package com.ust.ecommerce.exception;

public class ProductNotFoundException extends Exception{
    public ProductNotFoundException(String s){
        super(s);
    }
}
