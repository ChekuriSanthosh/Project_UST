package com.ust.ecommerce.model;

public enum Size {
    EXTRA_SMALL, SMALL, MEDIUM, LARGE, EXTRA_LARGE;
}
