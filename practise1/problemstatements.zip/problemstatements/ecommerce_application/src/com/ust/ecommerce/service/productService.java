package com.ust.ecommerce.service;

import com.ust.ecommerce.exception.DuplicateProductException;
import com.ust.ecommerce.exception.InvalidInputException;
import com.ust.ecommerce.exception.ProductNotFoundException;
import com.ust.ecommerce.model.Product;

public interface productService {
    public void addProductstodata(Product product) throws InvalidInputException, DuplicateProductException;
    public void viewallProductsdata();
    public Product findProductdata(int id) throws ProductNotFoundException;
}
