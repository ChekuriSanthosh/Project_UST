package com.ust.ecommerce.exception;

public class DuplicateProductException extends Exception{
    public DuplicateProductException(String message) {
        super(message);
    }
}
