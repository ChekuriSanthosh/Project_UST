package com.ust.ecommerce.service;

import com.ust.ecommerce.exception.DuplicateProductException;
import com.ust.ecommerce.exception.InvalidInputException;
import com.ust.ecommerce.exception.ProductNotFoundException;
import com.ust.ecommerce.model.Product;
import com.ust.ecommerce.repository.Cart;
import com.ust.ecommerce.repository.cartImpl;
import com.ust.ecommerce.repository.Products;
import com.ust.ecommerce.repository.ProductsImpl;

import java.util.ArrayList;

public class ProductServiceImpl implements productService{

    private Products productRepo= new ProductsImpl();

    public void addProductstodata(Product product) throws InvalidInputException, DuplicateProductException {
        productRepo.addProductsdata(product);
    }

    public void viewallProductsdata(){
        productRepo.viewallProducts();
    }

    public Product findProductdata(int id) throws ProductNotFoundException {
        return productRepo.findProduc(id);

    }
}
