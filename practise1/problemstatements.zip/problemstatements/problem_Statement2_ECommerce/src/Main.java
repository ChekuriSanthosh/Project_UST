package com.ust.ecommerce;

import com.ust.ecommerce.exception.DuplicateProductException;
import com.ust.ecommerce.exception.ProductNotFoundException;
import com.ust.ecommerce.model.Clothing;
import com.ust.ecommerce.model.Electronics;
import com.ust.ecommerce.model.Product;
import com.ust.ecommerce.model.Size;
import com.ust.ecommerce.service.cartService;
import com.ust.ecommerce.service.cartServiceImpl;
import com.ust.ecommerce.service.productService;
import com.ust.ecommerce.service.ProductServiceImpl;

import javax.sound.midi.Soundbank;
import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Product ep1 = new Electronics("Macbook",12,195000,4,"Apple",12);
        Product ep2 = new Electronics("S24 Ultra",2,150000,5,"Samsung",13);

        Product cp1 = new Clothing("T-Shirt",20,2000,10, "cotton",Size.MEDIUM);
        Product cp2 = new Clothing("Pant",10,4000,20, "Silk",Size.EXTRA_SMALL);

        cartService Service = new cartServiceImpl();
        productService Productserv=new ProductServiceImpl();

        try {
            Productserv.addProductstodata(ep1);
            Productserv.addProductstodata(ep2);
            Productserv.addProductstodata(cp1);
            Productserv.addProductstodata(cp2);
        }catch (Exception e){
            System.out.println(e);
        }

        Productserv.viewallProductsdata();
        System.out.println("___________________________________________________________");
        try{
            Product pro= Productserv.findProductdata(23);
            pro.displayDetails();
        }catch (ProductNotFoundException e){
            System.out.println(e.getMessage());
        }

        System.out.println("_____________________________________________________________");

        try {
            Productserv.addProductstodata(cp1);
        }catch (Exception e){
            System.out.println(e.getMessage());
        }


        System.out.println("___________________________________________________________________");
        System.out.println("___________________________________________________________________");
        System.out.println("___________________________________________________________________");
        Service.addToCArt(12);
        try {
            Service.findproduct(-1);
        }
        catch (Exception e){
            System.out.println(e);
        }

        Product[] products = Service.getCartItems();
        System.out.println("\u001B[33mProducts in Cart : \033[0m");
        for (Product p:products){
            if (p==null){
                break;
            }
            p.displayDetails();
        }
        System.out.println("______________________________________________________________");
        double totalPrice = Service.calculateTotalPrice();
        System.out.println("Total : "+totalPrice);

        Service.applyDiscounts();

        double discountedPrice = Service.calculateTotalPrice();

        System.out.println("After Discounts : "+discountedPrice);




        while(true){
            Scanner scanner=new Scanner(System.in);
            System.out.println("""
                welcome to My Shopping App!
                Select an option:
                1. View all Products
                2. Add Product to cart
                3. View Cart
                """);

            int res=scanner.nextInt();
            switch (res){
                case 1:
                    Productserv.viewallProductsdata();
                    break;
                case 2:
                    System.out.println("Enter the product id to add: ");
                    int id=scanner.nextInt();
                    Service.addToCArt(id);
                    System.out.println("added to the cart!!!!");
                case 3:
                    System.out.println("_____________________________________________________");
                    Product[] productss = Service.getCartItems();
                    System.out.println("Products in Cart : ");
                    for (Product p:productss){
                        if (p==null){
                            break;
                        }
                        p.displayDetails();
                        System.out.println("_____________________________________________________");
                    }

            }
        }


    }
}