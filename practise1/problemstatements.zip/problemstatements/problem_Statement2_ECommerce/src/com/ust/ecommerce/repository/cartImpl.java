package com.ust.ecommerce.repository;

import com.ust.ecommerce.model.Product;
import com.ust.ecommerce.repository.ProductsImpl;

import java.io.IOException;
import java.util.ArrayList;

public class cartImpl implements Cart{
    public static Product[] cartss=new Product[10];
    public static Products allproduc=new ProductsImpl();
    int pos=0;
    Product[] allproducts=allproduc.getAll();

    public void addProduct(int id) {

        for(Product p:allproducts){
            if(p==null){
                break;
            }
            if(pos==10){
                System.out.println("Cart is Full, Can't add anymore!!");
            }
            else if(p.getProductId()==id){
                cartss[pos]=p;
                pos++;
            }
        }
    }
    public Product findProduct(int id) throws IOException {
        if(id<=0){
            throw new ArithmeticException("Id is less than zero");
        }
        for(Product p:cartss){
            if(p==null){
                break;
            }
            if(p.getProductId()==id){
                return p;
            }
        }
        return null;
    }

    public Product[] getAllProducts(){
        return cartss;
    }
}
