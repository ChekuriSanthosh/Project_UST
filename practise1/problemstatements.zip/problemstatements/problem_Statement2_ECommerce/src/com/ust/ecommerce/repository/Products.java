package com.ust.ecommerce.repository;
import com.ust.ecommerce.exception.DuplicateProductException;
import com.ust.ecommerce.exception.InvalidInputException;
import com.ust.ecommerce.exception.ProductNotFoundException;
import com.ust.ecommerce.model.Product;

import java.util.ArrayList;

public interface Products {

    void addProductsdata(Product product) throws InvalidInputException, DuplicateProductException;
    void viewallProducts();
    Product[] getAll();
    Product findProduc(int id) throws ProductNotFoundException;

}
