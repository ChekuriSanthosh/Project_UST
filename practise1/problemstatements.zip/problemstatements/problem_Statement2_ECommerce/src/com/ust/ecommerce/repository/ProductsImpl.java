package com.ust.ecommerce.repository;
import com.ust.ecommerce.exception.DuplicateProductException;
import com.ust.ecommerce.exception.InvalidInputException;
import com.ust.ecommerce.exception.ProductNotFoundException;
import com.ust.ecommerce.model.Product;

import java.util.ArrayList;

public class ProductsImpl implements Products{
    public static Product[] allProducts=new Product[10];
    int pos=0;

    public void addProductsdata(Product product) throws InvalidInputException, DuplicateProductException {
        for(Product p:allProducts){
            if(p==null){
                break;
            }
            if(p.getProductId()==product.getProductId()){
                throw new DuplicateProductException("Tried Product Duplication with id: "+product.getProductId());
            }
        }

        if(product.getProductId()<0 || product.getProductName()==null || product.getProductName()==""|| product.getPrice()<0){
            throw new InvalidInputException();
        }
        if(pos==10){
            System.out.println("Products are at a max Limit, can't product");
        }
        else {
            allProducts[pos]=product;
            pos++;
        }
    }

    public void viewallProducts(){
        for(Product p: allProducts){
            if(p==null){
                break;
            }
            p.displayDetails();
        }
    }

    public Product[] getAll(){
        return allProducts;
    }

    public Product findProduc(int id) throws ProductNotFoundException{
        for(Product p:allProducts){
            if(p==null){
                break;
            }
            if(p.getProductId()==id){
                return p;
            }
        }

        throw new ProductNotFoundException("Product not found with the given id "+id);


    }


}
