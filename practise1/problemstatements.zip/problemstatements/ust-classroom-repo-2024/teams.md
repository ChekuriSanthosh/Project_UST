| **Team**                                                                  | **Member 1**    | **Member 2**    | **Member 3**                   | **Member 4**         |
| ------------------------------------------------------------------------- | --------------- | --------------- | ------------------------------ | -------------------- |
| **https://gitlab-ust.stackroute.in/ust-campus-team-1/ust-campus-team-1**  | Charan          | Pranith Kumar   | Fathima Vadakekuttikkattuthara | Gokul Sree           |
| **https://gitlab-ust.stackroute.in/ust-campus-team2/ust-campus-team2**    | Suhel Faraz     | Hemanth         | Bharadwaj                      | Sahithi              |
| **https://gitlab-ust.stackroute.in/ust-campus-group-3/ust-campus-team-3** | Vishwas Reddy   | Brijesh Kumar   | Eugene                         | Deepak               |
| **https://gitlab-ust.stackroute.in/ust-campus-team4/team4_project**       | Hariprasad      | Sai Vignay Goud | Amaan Ali                      | Anup, Rakesh         |
| **https://gitlab-ust.stackroute.in/ust-campus-team-5/ust-campus-team-5**  | Maarcus Reniero | Susrutha        | Pavan Kumar                    | Shrinivas Dhanwant   |
| **https://gitlab-ust.stackroute.in/ust-campus-team-6/ust-campus-team-6**  | Sujitha         | Abhishek        | Manyasrisai                    | Megha                |
| **https://gitlab-ust.stackroute.in/ust-trv-2024/ust-campus-team-7**       | Santhosh        | Sahil           | Gautham                        | Chandra Lokesh Chary |
| **https://gitlab-ust.stackroute.in/ust-campus-team8/project-team8**       | Akash           | Lokeshwar Reddy | Joel Chiriyankandath           | Yamini               |
