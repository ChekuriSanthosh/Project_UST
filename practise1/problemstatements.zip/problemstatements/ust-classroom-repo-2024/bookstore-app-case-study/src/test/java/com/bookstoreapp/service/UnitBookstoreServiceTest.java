package com.bookstoreapp.service;

import com.bookstoreapp.exception.BookAlreadyExistsException;
import com.bookstoreapp.exception.BookNotFoundException;
import com.bookstoreapp.model.Book;
import junit.framework.TestCase;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

/**
 * Unit test for simple App.
 */
@Slf4j
public class UnitBookstoreServiceTest extends TestCase {
    private static final Logger log = LoggerFactory.getLogger(UnitBookstoreServiceTest.class);

    private BookstoreService bookstoreService;
    Book book1=new Book(1,"Doom of Valariya","Martin",1990,1000000000,25000.00);
    Book book=new Book(2,"Dance of Dragons","GeorgeRR",2000,1000000000,89000.00);
    @BeforeEach
    void setup(){
        bookstoreService=new BookstoreServiceImpl();
        log.info("Object created");
        bookstoreService.saveBook(book1);
        bookstoreService.saveBook(book);
    }

    @AfterEach
    void afterset(){
        bookstoreService.deleteBook(1);
        bookstoreService.deleteBook(2);
        bookstoreService=null;
        log.info("Object Destroyed");
    }

    @Test
    public void UnitGetallBooks(){
        assertEquals(2,bookstoreService.getAllBooks().size());
        assertEquals(book1.getId(),bookstoreService.getAllBooks().get(0).getId());
    }

    @Test

    public void UnitSaveBookById() {

        assertEquals(2, bookstoreService.getAllBooks().size());
        Assertions.assertThrows(BookAlreadyExistsException.class, () -> {
            bookstoreService.saveBook(book1);

        });
    }


    @Test
    public void UnitfindBookById(){

        assertEquals(book1.getAuthor(),bookstoreService.getBookById(book1.getId()).getAuthor());
        assertEquals(book.getTitle(),bookstoreService.getBookById(book.getId()).getTitle());
        Assertions.assertThrows(BookNotFoundException.class,()->{
            bookstoreService.getBookById(20);
        });

    }


    @Test
    public void UnitDeleteById(){
        Book book2=new Book(3,"santhosh","santhosh",2000,1000000000,23000.00);
        bookstoreService.saveBook(book2);
        assertTrue(bookstoreService.getAllBooks().size()==3);
        bookstoreService.deleteBook(book2.getId());
        assertEquals(2,bookstoreService.getAllBooks().size());
        Assertions.assertThrows(BookNotFoundException.class,()->{
            bookstoreService.deleteBook(20);
        });
    }

    @Test
    public void UnitUpdateById(){
        Book book2=new Book(1,"Game of Thrones","Martin",1990,1000000000,25000.00);
        bookstoreService.updateBook(1,book2);
        assertEquals(book2.getTitle(),bookstoreService.getBookById(1).getTitle());
        Assertions.assertThrows(BookNotFoundException.class,()->{
            bookstoreService.updateBook(20,book2);
        });
    }

    @Test
    public void validations(){
        Book book2=new Book(1,"Game of Thrones","Martin",1990,1000000000,25000.00);


    }




}
