package com.bookstoreapp.repository;

import com.bookstoreapp.exception.BookAlreadyExistsException;
import com.bookstoreapp.exception.BookNotFoundException;
import com.bookstoreapp.model.Book;
import com.bookstoreapp.util.utiljdbcConnection;

import java.sql.*;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class BookRepositoryImpl implements BookRepository{

    public List<Book> findAll() {
        Connection connection= utiljdbcConnection.createConnection();
        String sql="Select * from books";
        try {
            Statement statement=connection.createStatement();
            ResultSet resultSet=statement.executeQuery(sql);
            List<Book> listbooks=new ArrayList<>();
            while(resultSet.next()){
                int id=resultSet.getInt("id");
                String title=resultSet.getString("title");
                String author=resultSet.getString("author");
                int publishyear=resultSet.getInt("publicationYear");
                long isbn =resultSet.getInt("isbn");
                double price=resultSet.getDouble("price");

                Book book=new Book(id,title,author,publishyear,isbn,price);
                listbooks.add(book);
            }
            return listbooks;

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public Optional<Book> findById(int id) {

        Connection connection= utiljdbcConnection.createConnection();
        String sql="select * from books where id=?";

        try {
            PreparedStatement statement= connection.prepareStatement(sql);
            statement.setInt(1,id);
            ResultSet resultSet=statement.executeQuery();
            if(resultSet.next()){
                int id1 =resultSet.getInt("id");
                String title=resultSet.getString("title");
                String author=resultSet.getString("author");
                int publishyear=resultSet.getInt("publicationYear");
                long isbn =resultSet.getInt("isbn");
                double price=resultSet.getDouble("price");

                Book book=new Book(id1,title,author,publishyear,isbn,price);
                return Optional.of(book);
            }
            return Optional.empty();
        }catch (SQLException e){
            throw new RuntimeException(e);
        }

    }


    public Book save(Book book) {

        Connection connection= utiljdbcConnection.createConnection();
        String sql= """
                insert into books(id,title,author,publicationYear,isbn,price) values(?,?,?,?,?,?)
                """;
        try {
            PreparedStatement statement= connection.prepareStatement(sql);
            statement.setInt(1,book.getId());
            statement.setString(2,book.getTitle());
            statement.setString(3, book.getAuthor());
            statement.setInt(4,book.getPublicationYear());
            statement.setLong(5,book.getIsbn());
            statement.setDouble(6,book.getPrice());
            statement.executeUpdate();
            return book;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void deleteById(int id) {
        if(findById(id).equals(Optional.empty())){
            throw new BookNotFoundException("Book not Found");
        }
        Connection connection= utiljdbcConnection.createConnection();
        String sql= """
                delete from books where id=?
                """;
        try {
            PreparedStatement statement= connection.prepareStatement(sql);
            statement.setInt(1,id);
            statement.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

    }

    @Override
    public Book update(Book book) {

        if(findById(book.getId()).equals(Optional.empty())){
            throw new BookNotFoundException("Book not Found");
        }

        Connection connection= utiljdbcConnection.createConnection();
        String sql= """
                update books set title=?,author=?,publicationYear=?,isbn=?,price=? where id=? 
                """;
        try {
            PreparedStatement statement= connection.prepareStatement(sql);

            statement.setString(1,book.getTitle());
            statement.setString(2, book.getAuthor());
            statement.setInt(3,book.getPublicationYear());
            statement.setLong(4,book.getIsbn());
            statement.setDouble(5,book.getPrice());
            statement.setInt(6,book.getId());
            statement.executeUpdate();
            return book;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
}
