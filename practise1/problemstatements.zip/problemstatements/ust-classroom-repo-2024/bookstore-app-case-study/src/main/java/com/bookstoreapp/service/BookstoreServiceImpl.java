package com.bookstoreapp.service;

import com.bookstoreapp.exception.BookAlreadyExistsException;
import com.bookstoreapp.exception.BookNotFoundException;
import com.bookstoreapp.model.Book;
import com.bookstoreapp.repository.BookRepository;
import com.bookstoreapp.repository.BookRepositoryImpl;


import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;


public class BookstoreServiceImpl implements BookstoreService{


    private BookRepository bookRepository=new BookRepositoryImpl();

    @Override
    public List<Book> getAllBooks() {
            return  bookRepository.findAll();
    }

    @Override
    public Book getBookById(int id) {
//        if(bookRepository.findById(id).equals(Optional.empty())){
//            throw new BookNotFoundException("Book not found");
//        }
        // check if book exists
        // if book exists return book
        // else throw exception book not found
        return bookRepository.findById(id).orElseThrow(() -> new BookNotFoundException("Book not found"));
    }

    @Override
    public Book saveBook(Book book) {
        if(!bookRepository.findById(book.getId()).equals(Optional.empty())){
            throw new BookAlreadyExistsException("Book already Exists");
        }
        return bookRepository.save(book);

    }

    @Override
    public Book updateBook(int id, Book book) {

        if(bookRepository.findById(id).equals(Optional.empty())){
            throw new BookNotFoundException("Book Not Found");
        }
        return bookRepository.update(book);

    }

    @Override
    public void deleteBook(int id) {

        if(bookRepository.findById(id).equals(Optional.empty())){
            throw new BookNotFoundException("Book Not Found");
        }
        bookRepository.deleteById(id);

            // check if book exists
            // if book exists delete book
            // else throw exception book not found

    }


}
