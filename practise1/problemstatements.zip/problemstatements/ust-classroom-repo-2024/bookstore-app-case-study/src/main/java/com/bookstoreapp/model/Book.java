package com.bookstoreapp.model;


import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Book {


    private int id;

    @Override
    public String toString() {
        return "Book{" +
                "id=" + id +
                ", title='" + title + '\'' +
                ", author='" + author + '\'' +
                ", publicationYear=" + publicationYear +
                ", isbn=" + isbn +
                ", price=" + price +
                '}';
    }

    // The title should not be empty and should not exceed 100 characters
    private String title;

    // The author should not be empty and should not exceed 200 characters
    private String author;

    // The publication year should be a valid year
    private int publicationYear;

    // The ISBN should be a valid 10- or 13-digit number.
    private long isbn;

    // The price should be a positive decimal value.
    private double price;


    public Book(int id, String title, String author, int publicationYear, long isbn, double price) {
        setId(id);
        setTitle(title);
        setAuthor(author);
        setPublicationYear(publicationYear);
        setIsbn(isbn);
        setPrice(price);
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        if (title == null || title.isEmpty() || title.length() > 100) {
            throw new IllegalArgumentException("Title must not be empty and must not exceed 100 characters.");
        }
        this.title = title;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        if (author == null || author.isEmpty() || author.length() > 200) {
            throw new IllegalArgumentException("Author must not be empty and must not exceed 200 characters.");
        }
        this.author = author;
    }

    public int getPublicationYear() {
        return publicationYear;
    }

    public void setPublicationYear(int publicationYear) {
        if (publicationYear < 0) {
            throw new IllegalArgumentException("Publication year must be a valid year.");
        }
        this.publicationYear = publicationYear;
    }

    public long getIsbn() {
        return isbn;
    }

    public void setIsbn(long isbn) {
        String isbnStr = String.valueOf(isbn);
        String regex = "[0-9]+";
        Pattern p = Pattern.compile(regex);
        Matcher m = p.matcher(isbnStr);
        if (!m.matches() && !(isbnStr.length() == 10 || isbnStr.length() == 13)) {
            throw new IllegalArgumentException("ISBN must be a valid 10- or 13-digit number.");
        }
        this.isbn = isbn;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        if (price <= 0) {
            throw new IllegalArgumentException("Price must be a positive decimal value.");
        }
        this.price = price;
    }

}
