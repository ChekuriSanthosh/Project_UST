package com.bookstoreapp;


import com.bookstoreapp.model.Book;
import com.bookstoreapp.service.BookstoreService;
import com.bookstoreapp.service.BookstoreServiceImpl;

public class BookstoreAppApplication {

	public static void main(String[] args) {

		BookstoreService service=new BookstoreServiceImpl();
		Book book1=new Book(1,"Doom of Valariya","Martin",1990,1000000000,25000.00);

//		Book book=new Book(2,"Dance of Dragons","GeorgeRR",2000,1000000000,89000.00);
//		service.saveBook(book1);
//		service.saveBook(book);
//		service.updateBook(2,book);
		service.deleteBook(1);
		service.deleteBook(2);

//		System.out.println(service.getBookById(2));
		service.getAllBooks().forEach(System.out::println);

	}

}
