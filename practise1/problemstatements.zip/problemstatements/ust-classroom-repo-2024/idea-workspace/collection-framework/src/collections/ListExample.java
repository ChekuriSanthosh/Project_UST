package collections;

import java.util.*;

public class ListExample {

    public static void main(String[] args) {
        List<String> list = new Stack<>();



    }

}
