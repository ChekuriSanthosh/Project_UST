package model;

public enum Status {
    PENDING,COMPLETED;
}
