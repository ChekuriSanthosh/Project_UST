package com.ust.example.model;

public class Department {




}
