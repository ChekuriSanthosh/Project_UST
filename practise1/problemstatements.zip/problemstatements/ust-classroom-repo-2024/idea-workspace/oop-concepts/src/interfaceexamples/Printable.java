package interfaceexamples;

public interface Printable {

    void print();

}
