package javamethodcall;

public final class Student {

    private final String branch;

    public Student(String branch){
        this.branch=branch;
    }

    public String getBranch() {
        return branch;
    }
}
