package ecomapp.model;

public enum Size {
    X_SMALL,SMALL,MEDIUM,LARGE,X_LARGE;
}
