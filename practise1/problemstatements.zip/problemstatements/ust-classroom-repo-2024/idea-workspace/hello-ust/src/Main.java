public class Main {

    void print(){
        System.out.println("Hi...");
    }

    void play(){
        System.out.println("Lets Play");
    }

    public static void main(String[] args) {
        System.out.println("Hello world!");
        Main obj = new Main();
        obj.print();
        obj.play();
    }
}