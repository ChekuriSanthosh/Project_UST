package interfacesegregation;

public interface Scanner {
    public void scan();
}
