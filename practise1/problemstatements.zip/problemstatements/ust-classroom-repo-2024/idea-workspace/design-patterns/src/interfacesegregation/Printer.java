package interfacesegregation;

public interface Printer {
    public void print();

}
