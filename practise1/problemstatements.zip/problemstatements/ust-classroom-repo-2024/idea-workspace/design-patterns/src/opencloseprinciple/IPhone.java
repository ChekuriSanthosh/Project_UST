package opencloseprinciple;

public class IPhone extends Phone {
    public void takePictures(){
        System.out.println("Clicking great photos");
    }
}
