package opencloseprinciple;

public class Phone {

   public void takePictures(){
        System.out.println("Clicking Pictures");
    }

}
