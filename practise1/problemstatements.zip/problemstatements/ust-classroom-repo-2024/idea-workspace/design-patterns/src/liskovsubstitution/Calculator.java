package liskovsubstitution;

public class Calculator {


    public int changeSign(int a){
        return -a;
    }

}
