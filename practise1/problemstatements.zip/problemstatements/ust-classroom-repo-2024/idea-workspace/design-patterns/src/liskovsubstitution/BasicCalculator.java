package liskovsubstitution;

public class BasicCalculator extends Calculator{

    public int add(int a, int b){
        return a+b;
    }


}
