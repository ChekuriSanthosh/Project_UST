package designpatterns.structural.adapter;

public interface TypeCCharger {
    void chargeWithTypeC();
}
