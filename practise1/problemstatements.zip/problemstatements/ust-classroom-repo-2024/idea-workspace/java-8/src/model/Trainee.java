package model;

import java.util.List;

public record Trainee(int id, String name, List<String> programmingLanguages) {
}
