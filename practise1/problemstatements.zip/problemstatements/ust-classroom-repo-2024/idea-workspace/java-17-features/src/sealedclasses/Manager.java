package sealedclasses;

public non-sealed class Manager extends Employee {
}
