package strings;

public class StringBuilderExample {

    public static void main(String[] args) {

        StringBuilder sb1 = new StringBuilder("UST");

        sb1.reverse();



        System.out.println(sb1);

    }

}
