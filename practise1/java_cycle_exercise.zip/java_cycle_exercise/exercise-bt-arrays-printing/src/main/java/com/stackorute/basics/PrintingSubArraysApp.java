package com.stackorute.basics;


import java.util.*;

public class PrintingSubArraysApp {
    public static void main(String[] args) {

//        PrintingSubArraysApp printSubArrays;
        new PrintingSubArraysApp().getInput();

    }

    public int[][] generateSubArrays(int[] input) {
        List<int[]> arra=new ArrayList<int []>();
        if(input.length<=1){
            displayResult(null);
            return null;
        }
        for(int i=0;i< input.length;i++){
            for(int j=i;j< input.length;j++){
                int []res=Arrays.copyOfRange(input,i,j+1);
                arra.add(res);
            }
        }

//        arra.sort((a,b)->Integer.compare(sum(b),sum(a)));
        arra.sort((a, b) -> {
            int sumComparison = Integer.compare(sum(b), sum(a));
            if (sumComparison == 0) {
                return Integer.compare(a[0], b[0]);
            }
            return sumComparison;
        });

        int [][]finalarr=new int[arra.size()][];
        for(int i=0;i< arra.size();i++){
            finalarr[i]=arra.get(i);
//            System.out.println(finalarr[i]);
        }
        displayResult(finalarr);
        return finalarr;

    }

    private int sum(int[] b) {
        int sum=0;
        for(int i=0;i<b.length;i++){
            sum+=b[i];
        }
        return sum;
    }

    public int[] getInput() {

        Scanner scanner=new Scanner(System.in);
        String inputs=scanner.nextLine();
        String []res=inputs.split(" ");
        if(res.length<=2){
            displayResult(null);
            return null;
        }
        int n=Integer.parseInt(res[0]);
        int []arr=new int[n];
        if(n!=res.length-1){
            displayResult(null);
            return null;
        }

        /*
        reads the input array size and the input array elements from the user
        returns the input array
        */
        for(int i=1;i< res.length;i++){
            arr[i-1]=Integer.parseInt(res[i]);
        }
        generateSubArrays(arr);

        /*return inputArray;*/
        return arr;
    }

    public void displayResult(int[][] subArrays) {

        if(subArrays==null){
            System.out.println("Insufficient Array Elements");
            return;
        }
        for(int i=0;i<subArrays.length;i++){
            for(int j=0;j<subArrays[i].length;j++){
                System.out.print(subArrays[i][j]+" ");
            }
//            System.out.println();
        }
        /*
        prints all the sub arrays in the 2D array
        prints each sub array in separate line with each values separated by space
        prints 'Insufficient Array elements' when the argument is null
        */

    }
}