package com.stackroute.streams;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class FileOperationsUsingStreams {

    public int getUniqueWordCount(String file) throws FileNotFoundException {
//        File file1=new File(file);
        try {
            InputStream input=new FileInputStream(file);
        }catch (FileNotFoundException ex){
            return 0;
        }
        InputStream input=new FileInputStream(file);
        Set<String> hashset=new HashSet<String>();
        Scanner scanner=new Scanner(input);
        while (scanner.hasNextLine()){
            String res=scanner.nextLine();
            String []temp=res.split(" ");
            for(String s:temp){
                hashset.add(s);
            }

        }
        return hashset.size();

    }


    public Set<String> getWordListWithoutDuplicates(String file) throws FileNotFoundException {
        Set<String> hashset=new LinkedHashSet<>();
        try {
            InputStream input=new FileInputStream(file);
        }catch (FileNotFoundException ex){
            return hashset;
        }
        InputStream input=new FileInputStream(file);
        Scanner scanner=new Scanner(input);
        while (scanner.hasNextLine()){
            String res=scanner.nextLine();
            String []temp=res.split(" ");
            for(String s:temp){
                hashset.add(s);
            }

        }
        return hashset;
    }

    public List<String> getWordListInUppercaseExcludingFirstLine(String file) throws FileNotFoundException {
        List<String> hashlist=new ArrayList<>();
        try {
            InputStream input=new FileInputStream(file);
        }catch (FileNotFoundException ex){
            return hashlist;
        }
        InputStream input=new FileInputStream(file);
        Scanner scanner=new Scanner(input);
        scanner.nextLine();
        while (scanner.hasNextLine()){
            String res=scanner.nextLine();
            String []temp=res.split(" ");
            for(String s:temp){
                hashlist.add(s);
            }

        }
        return hashlist;
    }
    public String getEachWordsSeparatedByColon(String file) throws FileNotFoundException {
        List<String> hashlist=new ArrayList<>();
        try {
            InputStream input=new FileInputStream(file);
        }catch (FileNotFoundException ex){
            return null;
        }
        InputStream input=new FileInputStream(file);
        Scanner scanner=new Scanner(input);
        while (scanner.hasNextLine()){
            String res=scanner.nextLine();
            String []temp=res.split(" ");
            for(String s:temp){
                hashlist.add(s);
            }

        }
        String ans=hashlist.stream().collect(Collectors.joining(":"));
        return ans;
    }

    public String getEachLineSeparatedByComma(String file) throws FileNotFoundException {
        List<String> hashlist=new ArrayList<>();
        try {
            InputStream input=new FileInputStream(file);
        }catch (FileNotFoundException ex){
            return null;
        }
        InputStream input=new FileInputStream(file);
        Scanner scanner=new Scanner(input);
        while (scanner.hasNextLine()){
            String res=scanner.nextLine();
            hashlist.add(res);

        }
        String ans=hashlist.stream().collect(Collectors.joining(","));
        return ans;
    }


    public Optional<Integer> getMaxOfIntegers(String file) throws FileNotFoundException {
        if (file == null || !(file.trim().length() >0)) {
            return Optional.empty();
        }
        int ans=Integer.MIN_VALUE;
//        List<String> hashlist=new ArrayList<>();
        try {
            InputStream input=new FileInputStream(file);
        }catch (FileNotFoundException ex){
            return Optional.empty();
        }
        InputStream input=new FileInputStream(file);
        Scanner scanner=new Scanner(input);
        while (scanner.hasNextLine()){
            String res=scanner.nextLine();
            String []temp=res.split(" ");
            for(String s:temp){
                if(s.matches("\\d+") && ans<Integer.parseInt(s)){
                    ans=Integer.parseInt(s);
                }
            }

        }
        if(ans==Integer.MIN_VALUE){
            return Optional.empty();
        }
        return Optional.of(ans);
    }

    public Optional<Integer> getSumOfIntegers(String file) throws IOException {
        if (file == null || !(file.trim().length() >0)) {
            return Optional.empty();
        }
        int ans=0;
//        List<String> hashlist=new ArrayList<>();
        try {
            InputStream input=new FileInputStream(file);
        }catch (FileNotFoundException ex){
            return Optional.empty();
        }
        InputStream input=new FileInputStream(file);
        Scanner scanner=new Scanner(input);
//        scanner.nextLine();
        while (scanner.hasNextLine()){
            String res=scanner.nextLine();
            String []temp=res.split(" ");
            for(String s:temp){
                if(s.matches("\\d+")){
                    ans+=Integer.parseInt(s);
                }
            }

        }
        if(ans==0){
            return Optional.empty();
        }
        return Optional.of(ans);
    }



    }

