package com.stackroute.basics;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class SumOfCommonElements {
    //Create Scanner object as instance variable

    static String input="";
    static boolean flag=true;

    public static void main(String[] args) {
        //Get the size for the arrays
        SumOfCommonElements problem=new SumOfCommonElements();

        Scanner scanner=new Scanner(System.in);
        input=scanner.nextLine();
        String []temp=input.split(" ");

        if(temp.length<=3){
            flag=false;
        }
        int n=Integer.parseInt(temp[0]);
        if(temp.length-1!= 2*n){
            flag=false;
            problem.displayResult(-1);
        }else {
            int []arr=new int[2*n];
            for(int i=0;i<2*n;i++){
                arr[i]=Integer.parseInt(temp[i+1]);
            }
            int []arr1=new int[n];
            int []arr2=new int[n];
            for(int i=0;i<n;i++){
                arr1[i]=arr[i];
            }
            int j=n+1;
            for(int i=0;i<n;i++){
                arr2[i]=arr[i+n];
            }
            int ans= problem.calculateSumOfCommonElements(arr1,arr2);
            problem.displayResult(ans);
        }



        //Initialize the array elements using getArrayElements() method
    }

    public int getArraySize() {
        return 0;
    }

    public int[] getArrayElements(int size) {

        return null;
    }

    public void displayResult(int result) {
        //display the result
        if(result==-1 || !flag){
            System.out.println("No Elements in arrays");
        }else{
            System.out.println(result+"");
        }
    }

    public int calculateSumOfCommonElements(int[] firstArray, int[] secondArray) {
        ArrayList<Integer> m1=new ArrayList<>();
        if(firstArray==null || firstArray.length==0 || secondArray==null || secondArray.length==0){
            return -1;
        }
        int sum=0;
        for(int i=0;i<firstArray.length;i++){
            m1.add(firstArray[i]);
        }
        for(int i=0;i<secondArray.length;i++){
            if(m1.contains(secondArray[i])){
                sum+=secondArray[i];
            }
        }
        return sum;
    }
    public void closeScanner(){
    }

}
