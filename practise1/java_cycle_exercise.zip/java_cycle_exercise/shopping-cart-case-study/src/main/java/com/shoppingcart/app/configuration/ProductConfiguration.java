package com.shoppingcart.app.configuration;


import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Component;

@Component
@ComponentScan("com.shoppingcart.app")
public class ProductConfiguration {

}
