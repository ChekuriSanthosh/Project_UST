package com.shoppingcart.app.repository;

import com.shoppingcart.app.exception.InvalidQuantityException;
import com.shoppingcart.app.exception.ProductNotFoundException;
import com.shoppingcart.app.model.Product;
import org.springframework.stereotype.Repository;

import java.util.*;

@Repository
public class ShoppingCartRepositoryImpl implements ShoppingCartRepository {

    List<Product> allproducts=new ArrayList<>();

    public void addProduct(Product product, int quantity) throws InvalidQuantityException {
        if(quantity<=0){
            throw new InvalidQuantityException("Quantity is not valid");
        }
        allproducts.add(product);

    }

    public void removeProduct(Product product) throws ProductNotFoundException {

        if(!allproducts.contains(product)){
            throw new ProductNotFoundException("Product is not Valid");
        }

        allproducts.remove(product);

    }

    public void updateProductQuantity(Product product, int quantity) throws ProductNotFoundException, InvalidQuantityException {
        if(quantity<=0){
            throw new InvalidQuantityException("quantity is not valid");
        }
        if(!allproducts.contains(product)){
            throw new ProductNotFoundException("Product is not Valid");
        }
        allproducts.stream().filter(i->i==product).findFirst().get().setQuantity(quantity);

    }

    public double calculateTotalPrice() {
        return allproducts.stream().mapToDouble(i->i.getPrice()*i.getQuantity()).sum();
    }

    public List<Product> filterProductsByCategory(String category) {
        List<Product> res=allproducts;
        return res.stream().filter(i-> Objects.equals(i.getCategory(), category)).toList();
    }

    public List<Product> filterProductsByPriceRange(double minPrice, double maxPrice) {
        List<Product> res=allproducts;
        return res.stream().filter(i->i.getPrice()>=minPrice && i.getPrice()<=maxPrice).toList();
    }



    // Output Format:
    //Product1 2 10.0
    //Product2 3 20.0
    public void displayCartItems() {
        for(int i=0;i<allproducts.size();i++){
            System.out.print(allproducts.get(i).getName()+" "+allproducts.get(i).getQuantity()+" "+allproducts.get(i).getPrice()+'\n');
        }

    }

    public Optional<Product> findMostExpensiveProduct() {
        return allproducts.stream().max(Comparator.comparing(Product::getPrice));
    }

    public List<Product> sortProductsByName() {
        return  allproducts.stream().sorted((a,b)->
             a.getName().compareTo(b.getName())
        ).toList();
    }

    public double calculateDiscountedTotal(double discountPercentage) {
        double total=calculateTotalPrice();
        return total-(total*discountPercentage)/100;
    }

    public List<Product> getProducts() {

        return allproducts;
    }
}
