package com.shoppingcart.app;


import com.shoppingcart.app.configuration.ProductConfiguration;
import com.shoppingcart.app.exception.InvalidProductException;
import com.shoppingcart.app.exception.InvalidQuantityException;
import com.shoppingcart.app.model.Product;
import com.shoppingcart.app.service.ShoppingCartService;
import com.shoppingcart.app.service.ShoppingCartServiceImpl;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import java.util.HashMap;
import java.util.Map;

public class Main {
    public static void main(String[] args) throws InvalidQuantityException, InvalidProductException {
        ApplicationContext context=new AnnotationConfigApplicationContext(ProductConfiguration.class);

        ShoppingCartService shoppingCartService=context.getBean(ShoppingCartServiceImpl.class);

        Product p=new Product(1,"Shampoo","head",2000,2);

        shoppingCartService.addProduct(p,2);
        System.out.println(shoppingCartService.calculateTotalPrice());

        shoppingCartService.getProducts().forEach(System.out::println);

    }
}