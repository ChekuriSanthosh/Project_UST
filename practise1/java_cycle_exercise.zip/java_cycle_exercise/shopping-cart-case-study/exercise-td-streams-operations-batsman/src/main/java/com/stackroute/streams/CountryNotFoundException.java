package com.stackroute.streams;

import java.util.NoSuchElementException;

public class CountryNotFoundException extends NoSuchElementException {
    public CountryNotFoundException(String message) {
        super(message);
    }
}