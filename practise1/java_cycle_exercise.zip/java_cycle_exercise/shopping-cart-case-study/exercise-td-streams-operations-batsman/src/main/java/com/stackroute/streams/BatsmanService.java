package com.stackroute.streams;


import java.util.*;

public class BatsmanService {
    public Optional<Batsman> getBatsman(List<Batsman> batsmanList , String name , String countryCode) throws CountryNotFoundException{
        try {
            if (batsmanList == null || name == null || countryCode == null) return Optional.empty();
            String text = "";
            Optional<Batsman> batsman;
            for(Batsman b : batsmanList){
                if(b.getCountry().getCountryCode().equalsIgnoreCase(countryCode)){
                    text = countryCode;
                    break;
                }
            }
            if(text.isEmpty()) {
                throw new CountryNotFoundException("Country doesn't exist");
//                return ;
            }
            batsman = batsmanList.stream().filter(i -> i.getName().equalsIgnoreCase(name) && i.getCountry().getCountryCode().equalsIgnoreCase(countryCode)).findFirst();
            return batsman;
        } catch (RuntimeException ce) {
            throw new CountryNotFoundException(ce.getMessage());
        }
    }


    public String getBatsmanNamesForCountry(List<Batsman> batsmanLi, String code){
        if(code==null || batsmanLi==null || batsmanLi.isEmpty() || code.trim().isEmpty()){
            return null;
        }
        List<String>res= batsmanLi.stream().filter(i-> i.getCountry().getCountryCode().equalsIgnoreCase(code)).map(Batsman::getName).sorted().toList();
        String res1=String.join(",",res);
        return "["+res1+"]";
    }

    public Map<String, Integer> getPlayerNameWithTotalRuns(List<Batsman> batsmanList){
        Map<String,Integer>res=new LinkedHashMap<>();
        if(batsmanList==null || batsmanList.isEmpty()){
            return res;
        }
        List<Batsman>m=batsmanList.stream().peek(i->{
            if(res.containsKey(i.getName())){
                res.put(i.getName(),i.getTotalRuns()+res.get(i.getName()));
            }else{
                res.put(i.getName(),i.getTotalRuns());
            }
        }).toList();
        return res;
    }
    public int getHighestRunsScoredByBatsman(List<Batsman> batsmanList,String country){
        if(batsmanList==null || batsmanList.isEmpty() || country==null || country.isEmpty()){
            return 0;
        }
        final int[] ans = {Integer.MIN_VALUE};
        List<Batsman>res=batsmanList.stream().filter(i-> Objects.equals(i.getCountry().getName(), country)).peek(i->{
            if( i.getHighestScore()> ans[0]){
                ans[0] =i.getHighestScore();
            }
        }).toList();
        return ans[0];
    }

    public Optional<LinkedList<String>> getPlayerNamesByCountry(List<Batsman> batsmanList, String country){
        if(country==null || batsmanList==null || batsmanList.isEmpty() || country.trim().isEmpty()){
            return Optional.empty();
        }
        LinkedList<String>res1=new LinkedList<>();
        List<String>res= batsmanList.stream().filter(i-> i.getCountry().getName().equalsIgnoreCase(country) && i.getTotalRuns()>5000).map(Batsman::getName).toList();
        if(res.isEmpty()){
            return Optional.empty();
        }
        res1.addAll(res);
        return Optional.of(res1);
    }






}
