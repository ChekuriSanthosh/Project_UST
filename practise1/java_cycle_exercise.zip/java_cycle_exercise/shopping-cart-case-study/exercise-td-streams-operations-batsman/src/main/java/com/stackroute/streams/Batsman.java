package com.stackroute.streams;

public class Batsman {
    private String Name;
    private int MatchesPlayed;
    private int TotalRuns;
    private int HighestScore;
    Country country;

    public Batsman(String name, int matchesPlayed, int totalRuns, int highestScore, Country country) {
        Name = name;
        MatchesPlayed = matchesPlayed;
        TotalRuns = totalRuns;
        HighestScore = highestScore;
        this.country = country;
    }

    public Batsman() {
        Name=null;
        MatchesPlayed=0;
        TotalRuns=0;
        HighestScore=0;
        country=null;
    }


    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public int getMatchesPlayed() {
        return MatchesPlayed;
    }

    public void setMatchesPlayed(int matchesPlayed) {
        MatchesPlayed = matchesPlayed;
    }

    public int getTotalRuns() {
        return TotalRuns;
    }

    public void setTotalRuns(int totalRuns) {
        TotalRuns = totalRuns;
    }

    public int getHighestScore() {
        return HighestScore;
    }

    public void setHighestScore(int highestScore) {
        HighestScore = highestScore;
    }

    public Country getCountry() {
        return country;
    }

    public void setCountry(Country country) {
        this.country = country;
    }
}
