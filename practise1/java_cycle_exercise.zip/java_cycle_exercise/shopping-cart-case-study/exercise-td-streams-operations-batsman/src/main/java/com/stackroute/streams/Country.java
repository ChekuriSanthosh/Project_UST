package com.stackroute.streams;

public class Country {
    private String code;
    private String country;

    public Country(String code, String country) {
        this.code = code;
        this.country = country;
    }

    public Country() {
        this.code=null;
        this.country=null;
    }

    public String getName() {
        return country;
    }

    public void setName(String country) {
        this.country = country;
    }

    public String getCountryCode() {
        return code;
    }

    public void setCountryCode(String code) {
        this.code = code;
    }
}
