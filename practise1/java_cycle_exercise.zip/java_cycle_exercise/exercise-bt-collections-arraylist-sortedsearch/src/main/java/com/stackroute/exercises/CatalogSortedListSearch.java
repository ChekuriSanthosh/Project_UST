package com.stackroute.exercises;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

public class CatalogSortedListSearch {

    public static List<String> arr=new ArrayList<String>();
    //write here logic to get sorted Array List which is a global class variable
    public String catalogListSorter(List<String> unSortedCatalogList) {
        String res1="The catalog list is null";
        String res2="The catalog List is empty";
        if(unSortedCatalogList==null){
            return res1;
        }
        if(unSortedCatalogList.isEmpty()){
            return res2;
        }
        if(unSortedCatalogList.contains(null) || unSortedCatalogList.contains(" ") || unSortedCatalogList.contains("")){
            return "The catalog List contains empty or null or blank space as a value";
        }

        Collections.sort(unSortedCatalogList);
        arr=unSortedCatalogList;
        StringBuilder ans= new StringBuilder("[");
        for(int i=0;i<arr.size();i++){
            ans.append(arr.get(i));
            if(arr.size()-1!=i){
                ans.append(", ");
            }
        }
        ans.append("]");
        return ans.toString();
    }

    //write here logic to search the input value in sorted Array List
    public String catalogListSearcher(String value) {
        if(value=="" || value==null || value==" "){
            return "Input is not accepted";
        }
        if(arr.contains(null)){
            return "The catalog List contains empty or null or blank space as a value";
        }
        if(arr.contains("")){
            return "Input is not accepted";
        }

        String res1="Not Found";
        String res2="Found";
        for(int i=0;i<arr.size();i++){
            if(arr.get(i).toLowerCase().equals(value.toLowerCase())){
                return res2+": "+arr.get(i);
            }
        }
        return res1;
    }
}

