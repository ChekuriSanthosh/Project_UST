package com.stackroute.oops;

import java.util.*;

/*
    Class for Analyzing the products present in ProductRepository
 */
public class ProductService {

    /*
                Returns the name of the product given the productCode
             */
    public String findProductNameByCode(int productCode) {
        Product []products=ProductRepository.getProducts();
        Product res= Arrays.stream(products).filter(i->i.getProductCode()==productCode).findFirst().orElse(null);
        if(res==null){
            return null;
        }
        return res.getName();
    }

    /*
        Returns the Product with maximum price in a given category
     */
    public Product findMaxPriceProductInCategory(String category) {
        Product []products=ProductRepository.getProducts();
        return Arrays.stream(products).filter(i-> Objects.equals(i.getCategory(), category)).max(Comparator.comparing(Product::getPrice)).orElse(null);
    }

    /*
        Returns an array of products for a given category
     */
    public Product[] getProductsByCategory(String category) {
        Product []products=ProductRepository.getProducts();
        Product []res=Arrays.stream(products).filter(i-> Objects.equals(i.getCategory(), category)).toArray(Product[]::new);
        return res.length==0?null:res;

    }
}
