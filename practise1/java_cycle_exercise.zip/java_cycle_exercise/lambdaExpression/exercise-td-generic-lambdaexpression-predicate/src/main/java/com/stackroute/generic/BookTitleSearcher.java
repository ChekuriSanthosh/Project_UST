package com.stackroute.generic;

import java.util.*;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public class BookTitleSearcher {
    public List<String> books;

    public BookTitleSearcher(){
        books=new ArrayList<>();
    }


    public Optional<List<String>> getBookList(List<String> booksList, String searchTerm) {
        Optional<List<String>> s;
        if (booksList == null || searchTerm == null || searchTerm.isEmpty() || booksList.size()==0) {
            return Optional.empty();
        }

        List<String> res=new ArrayList<>();
        String lowerCaseSearchTerm = searchTerm.toLowerCase();

        res=booksList.stream()
                .filter(book -> book.toLowerCase().contains(lowerCaseSearchTerm)).toList();
        return Optional.of(res);
    }

    public Optional<List<String>> searchBookNames(List<String> booksList, Predicate<String> predicate) {
        if(booksList==null || booksList.size()==0 || predicate==null){
            return Optional.empty();
        }

        List<String> res=new ArrayList<>();
        res=booksList.stream().filter(predicate).collect(Collectors.toList());
        return Optional.of(res);
    }
}
