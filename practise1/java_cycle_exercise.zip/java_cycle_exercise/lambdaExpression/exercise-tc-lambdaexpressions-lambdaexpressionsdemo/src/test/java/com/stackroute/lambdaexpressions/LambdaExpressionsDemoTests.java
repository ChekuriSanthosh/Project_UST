package com.stackroute.lambdaexpressions;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.util.List;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
public class LambdaExpressionsDemoTests {
    private LambdaExpressionsDemo expressionsDemo;
    @BeforeEach
    public void setup(){
        expressionsDemo=new LambdaExpressionsDemo();
    }
    @AfterEach
    public void teardown(){
        expressionsDemo=null;
    }
    @Test
    public void ArithmeticOperationMethodCalledWithlistofInteger(){
        assertEquals( List.of(10,5,2,1), expressionsDemo.arithmeticOperation(List.of(1,2,5,10),10),"The ouput for the Arthemetic operation is not equal or valid");
    }
    @Test
    public void ArithmeticOperationMethodCalledWithlistContainsZeroValue(){
        assertThrows(RuntimeException.class,()->expressionsDemo.arithmeticOperation(List.of(1,2,0,10), 10), "Use try catch to handle the exception");
    }
    @Test
    public void arithmeticOperationMethodCalledWithEmptyList(){
        assertEquals(List.of(),expressionsDemo.arithmeticOperation(List.of(),10));
    }
    @Test
    public void arithmeticOperationMethodCalledWithNULLlist(){
        assertThrows(RuntimeException.class,()->expressionsDemo.arithmeticOperation(null,10));
        assertThrows(RuntimeException.class,()->expressionsDemo.arithmeticOperation(List.of(),null));
    }
    @Test
    public void writeToFileMethodCalledwithListofStringValuesand0Offset(){
        assertEquals(List.of("file1.txt","file2.txt","file3.txt"),expressionsDemo.writeToFile(0,List.of("Santhosh","Pranith","Kodi")));
    }
    @Test
    public void writeToFileMethodcalledWithListofStringValuesandOffset10(){
        assertThrows(RuntimeException.class,()->expressionsDemo.writeToFile(10,List.of("Santhosh","Pranith","Kodibharadwaj")));

    }
    @Test
    public void writeToFileMethodCalledWithemptyListandanOffset(){
        assertEquals(List.of(),expressionsDemo.writeToFile(0,List.of()));
    }
    @Test
    public void writeToFileMethodCalledWithnullValues(){
        assertThrows(RuntimeException.class,()->expressionsDemo.writeToFile(0,null));

    }
}
