package com.stackroute.lamdbaexpression;

import java.util.ArrayList;
import java.util.List;

public class PredicateFunctionalInterface {
    //write logic to find the values that starts with letter I in the given list
    public List<String> findPattern(List<String> list) {
        List<String> ans=new ArrayList<>();
        if(list==null){
            return ans;
        }
        ans=list.stream().filter(i->i.charAt(0)=='I').distinct().toList();

        return ans;
    }
}
