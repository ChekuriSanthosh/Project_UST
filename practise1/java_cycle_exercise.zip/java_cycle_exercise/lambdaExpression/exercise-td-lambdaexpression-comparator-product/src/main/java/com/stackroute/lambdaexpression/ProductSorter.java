package com.stackroute.lambdaexpression;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class ProductSorter {
    ArrayList<Product> products;
    public ProductSorter(){
        products=new ArrayList<>();
    }

    public ArrayList<Product> getProductList(){
        return products;
    }

    public ArrayList<Product> sortProductByNameLength() {
        ArrayList<Product> res;
        res= (ArrayList<Product>) products.stream().sorted((a, b)->{
            int lencompare=Integer.compare(a.getName().trim().length(),b.getName().trim().length());
            if(lencompare!=0){
                return lencompare;
            }
            return a.getName().trim().compareTo(b.getName().trim());
        }).collect(Collectors.toList());
        return res;
    }

    public ArrayList<Product> sortProductByName() {
        ArrayList<Product> res;
        res= (ArrayList<Product>) products.stream().sorted((a, b)->{
            return a.getName().trim().compareTo(b.getName().trim());
        }).collect(Collectors.toList());
        return res;
    }

    public ArrayList<Product> sortProductByPriceDescending() {
        ArrayList<Product> res;
        res= (ArrayList<Product>) products.stream().sorted((a, b)->{
            return (int) (b.getPrice()-a.getPrice());
        }).collect(Collectors.toList());
        return res;
    }

    public ArrayList<Product> sortProductByCategoryAscendingAndByPriceDescending() {
        ArrayList<Product> res;
        res= (ArrayList<Product>) products.stream().sorted((a, b)->{
            int lencompare=a.getCategory().compareTo(b.getCategory());
            if(lencompare!=0){
                return lencompare;
            }
            return (int) (b.getPrice()-a.getPrice());
        }).collect(Collectors.toList());
        return res;
    }



}
