package com.stackroute.exercises;


import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class StringSort {

    //write here logic to sort a string List
    public String stringSorter(List<String> stringList, String sortingOrder) {
        if(stringList==null || stringList.size()==0 || sortingOrder==null|| sortingOrder=="" || sortingOrder.trim().length()==0){
            return "Given stringList or sortingOrder is empty, null or blank space";
        }
        for(int i=0;i<stringList.size();i++){
            if(stringList.get(i)==null || stringList.get(i).trim().length()==0){
                return "The list contains an empty or blank space value";
            }
        }
        if(stringList.size()==1){
            return "The list contains only one value";
        }
        sortingOrder=sortingOrder.toLowerCase();
        String result="";
        if(sortingOrder.equals("asc")){
            result=stringList.stream().sorted().collect(Collectors.joining(", "));
        } else if (sortingOrder.equals("desc")) {
            result=stringList.stream().sorted(Comparator.reverseOrder()).collect(Collectors.joining(", "));
        }else{
            return "No sorting order present for given string '"+sortingOrder+"' , 'asc' for ascending order sort and 'desc' for descending order sort";
        }

        result="["+result+"]";
        return result;
    }
}
