package com.stackroute.exercises;


import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Map;

public class CartCheckout {

    //write here logic to add a Map values include tax using lambda expression
    public String billGenerator(Map<String, BigDecimal> cart, Double taxPercent) {
        if(taxPercent==null){
            return "The taxPercent cannot be null";
        }
        if(cart==null){
            return "The cart Map cannot be null";
        }
        if(cart.size()==0){
            return "The cart Map is empty";
        }
        double ans=0;
//        BigInteger.valueOf(ans);
        for(String key:cart.keySet()){
            if(key==null || key.trim().length()==0){
                return "The cart Map has null or empty or blank space as a value";
            }
//            ans.add(cart.get(key));
            ans+=cart.get(key).doubleValue();
        }
//        cart.values().stream().reduce(i->ans+=cart.get(i).doubleValue());
        if(taxPercent<0){
            return "The taxPercent cannot be negative";
        }

        ans=ans+(ans*taxPercent)/100;
        return ans+"";
    }
}
