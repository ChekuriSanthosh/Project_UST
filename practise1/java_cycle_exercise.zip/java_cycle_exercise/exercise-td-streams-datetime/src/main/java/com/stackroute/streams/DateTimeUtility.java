package com.stackroute.streams;

import java.time.*;
import java.time.chrono.ChronoLocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class DateTimeUtility {
    public List<String> getNextMonthWorkingDays(LocalDate today){
        List<String> res=new ArrayList<>();
        LocalDate firstOfNextMonth = today.plusMonths(1).withDayOfMonth(1);
        LocalDate lastOfNextMonth = firstOfNextMonth.withDayOfMonth(firstOfNextMonth.lengthOfMonth());
        LocalDate currentDate = firstOfNextMonth;
        while (!currentDate.isAfter(lastOfNextMonth)) {
            if (currentDate.getDayOfWeek().getValue() <= 5) {
                res.add(currentDate.toString());
            }
            currentDate = currentDate.plusDays(1);
        }
        System.out.println(res);
        return res;
    }

    public List<String> getScheduledBusDepartureTimings(String start, Duration frequency){
        if(frequency.getSeconds()>=86400){
            return new ArrayList<>();
        }
        LocalTime startTime = LocalTime.parse(start);
        LocalTime stop=startTime;
        List<String> timings = new ArrayList<>();
        if(startTime.getSecond()<10){
            timings.add(startTime.toString()+":0"+startTime.getSecond());
        }else{
            timings.add(startTime.toString()+":"+startTime.getSecond());
        }
        while(startTime.isBefore(LocalTime.parse("23:59:59")) && startTime.getHour()>=stop.getHour()) {
            startTime=startTime.plus(frequency);
            if(startTime.getHour()< stop.getHour()){
                break;
            }
            if(startTime.getSecond()<10){
                timings.add(startTime.toString()+":0"+startTime.getSecond());
            }else{
                timings.add(startTime.toString()+":"+startTime.getSecond());
            }
        }
        System.out.println(timings);
        return timings;

    }

}
