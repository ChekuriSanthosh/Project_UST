package com.stackroute.arrays;

import java.util.HashMap;
import java.util.Scanner;

class Objects {
    boolean istrue;
    public Objects(boolean istrue) {
        this.istrue = istrue;
    }
}

public class CheckingForConsecutiveNumbersApp {
    static boolean flag =false;
    static Objects object=new Objects(true);
    public static void main(String[] args) {
        new CheckingForConsecutiveNumbersApp().readInput();
    }

    //write logic to get inputs from user and send inputs to inputValidator
    public void readInput() {
        Scanner scanner=new Scanner(System.in);
        String input= scanner.nextLine();
        inputValidator(input);

    }

    //write logic to send inputs to checkStrongNumber
    public void inputValidator(String input) {
        if(checkForConsecutive(input)){
            object.istrue=true;
        }else{
            object.istrue=false;
        }
        displayResult(object);
    }

    //write logic to check given numbers are consecutive or not and returns true if numbers are consecutive otherwise false
    public boolean checkForConsecutive(String input) {
        String[] resultant=input.split(",");
        HashMap<Integer,Integer> resmap=new HashMap<>();
        int maximum=Integer.MIN_VALUE;
        int minimum=Integer.MAX_VALUE;
        for(int i=0;i<resultant.length;i++){
            Integer res=Integer.parseInt(resultant[i]);
            if(res>maximum){
                maximum=res;
            }
            if(res<minimum){
                minimum=res;
            }

            if (resmap.containsKey(res)) {
                resmap.put(res, resmap.get(res) + 1);
            }
            else {
                resmap.put(res, 1);
            }
        }
        for(int i=minimum+1;i<maximum;i++){
            if(!resmap.containsKey(i)){
                return false;
            }
        }
        return true;
    }

    //write logic to print the given printStatement
    public void displayResult(Objects printStatement) {
        if(printStatement.istrue){
            System.out.println("Given numbers are Consecutive");
        }else{
            System.out.println("Given numbers are not Consecutive");
        }

    }
}
