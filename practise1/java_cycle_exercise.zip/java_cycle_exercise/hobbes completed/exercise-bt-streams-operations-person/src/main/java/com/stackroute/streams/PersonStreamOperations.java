package com.stackroute.streams;

import java.util.*;
import java.util.stream.Collectors;

/**
 * This class has various methods to do stream operations on person collection
 */
public class PersonStreamOperations {

    /**
     * sorts the person list alphabetically in uppercase
     * Returns Empty Optional if the given list is null or empty
     *
     * @param personList
     * @return
     */
    public Optional<List<String>> getPersonListSortedByNameInUpperCase(List<String> personList) {

        if(personList==null || personList.size()==0){
            System.out.println("List or name to search cannot be null");
            return Optional.empty();
        }

        var res2=personList.stream().filter(i->i.trim().length()>0).sorted().map(i->i.toUpperCase()).toList();
        Optional<List<String>> ans=Optional.of(res2);


        return ans;
    }

    /**
     * Sorts the distinct person names in descending order
     * Returns empty set if the given list is empty or null
     *
     * @param personList
     * @return
     */

    public Set<String> getDistinctPersonNamesSortedInDescendingOrder(List<String> personList) {
        Set<String> ans=new LinkedHashSet<>();
        if(personList==null || personList.size()==0){
            System.out.println("List or name to search cannot be null");
            return ans;
        }
        List<String> res=personList.stream().filter(i->i.trim().length()>0).sorted(Comparator.reverseOrder()).toList();

        for(String s:res){
            ans.add(s);
        }
        return ans;
    }



    /**
     * Returns "Person found" if the person searched is available in the list or else returns "Person not found"
     * Returns "Give proper input not null" if the given list or name to search is null
     *
     * @param personList
     * @return
     */
    public String searchPerson(List<String> personList, String nameToSearch) {
        if(personList==null || personList.size()==0 || nameToSearch==null){
            return  "Give proper input not null";
        }

        List<String> res=personList.stream().filter(i->i.equalsIgnoreCase(nameToSearch)).toList();
        if(res.size()>0){
            return "Person found";
        }else{
            return "Person not found";
        }
    }

    /**
     * Filters the list whose name length is greater than five and sorts by name length
     * Returns empty list if the given list is empty or null
     *
     * @param personList
     * @return
     */

    public List<String> getPersonListSortedByLengthWithNameLengthGreaterThanFive(List<String> personList) {
        List<String> ans=new ArrayList<>();
        if(personList==null || personList.size()==0){
            System.out.println("List or name to search cannot be null");
            return ans;
        }
        ans=personList.stream().filter(i->i.length()>5).sorted((a,b)->a.length()-b.length()).toList();
        return ans;
    }

    /**
     * Returns the person name having maximum age from the given Map<String,Integer> having name as key and age as value
     * Returns "Give proper input not null" if the given map is empty or null
     *
     * @param personMap
     * @return
     */

    public String getPersonByMaxAge(Map<String, Integer> personMap) {
        if(personMap==null || personMap.size()==0){
            return "Give proper input not null";
        }
        String res="";
        int age=0;
        for(String key:personMap.keySet()){
            if(personMap.get(key)>age){
                age=personMap.get(key);
                res=key;
            }
        }

        return res;
    }

}
