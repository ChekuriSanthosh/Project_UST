## Problem Statement: Find sum of neighbours of each element in a Two Dimensional Array ##

**Given a valid 2D Array, you need to write a method that will compute the sum of all neighbours for each element in the array. The method should store the sums in a new 2D Array and should return the array. 
  The position of each sum in the returned array should be same as the position of its element in the input array. Given a Invalid 2D Array, the method should return null. 
  For an element in a 2D array, neighbour elements are those which lies immediate to it in any direction. The given 2D array should have minimum row and column of 2**
   
**This exercise contains a class named SumOfNeighbours with the following methods:**

    +readInput() : void
        -Should accept inputs from the console 
        -Should call inputValidator method with given input
        -Should call displayResult with null if input is invalid
------------------------------------------------------
    +inputValidator(int[]) : boolean
        -Should accept input as int array and validate it 
        -Should check given row and column size is greater than 1 or not
        -Should return true if input is valid otherwise false
------------------------------------------------------
    +computeSumOfNeighbours(int[][]) : int[][]
        -Should get 2D array as input and return 2D array as output 
        -Should compute the sum of neighbours in the given 2D array
------------------------------------------------------
    +displayResult(int[][]) : void
        -Should accept int[][] as input and print it
        -Should print "Give proper input" if given input 2D array is null

## Example
    Sample Input:
    3 3 
    1 2 3 
    4 5 6 
    7 8 9 
    
    Expected Output: 
    11 19 13 
    23 40 27 
    17 31 19 
--------------------------------------------------------
    Sample Input:
    2 4 
    1 2 3 4
    5 6 7 8 
    
    Expected Output:
    13 22 27 18 
    9 18 23 14 
--------------------------------------------------------
    Sample Input:
    1 2 
     
        
    Expected Output:
    Give proper input

## Instructions
- Avoid printing unnecessary values other than expected output as given in sample
- Take care of whitespace/trailing whitespace
- Do not change the provided class/method names unless instructed
- Follow best practices while coding
