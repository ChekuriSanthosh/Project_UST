package com.stackroute.arrays;

import java.util.Scanner;

public class SumOfNeighbours {
    static boolean flag=true;
    public static void main(String[] args) {
        new SumOfNeighbours().readInput();
    }

    //write logic to get inputs from user and send inputs to inputValidator
    public void readInput() {
        Scanner scanner = new Scanner(System.in);
        String dimensions= scanner.nextLine();
        if (dimensions==null) {
            displayResult(null);
            return;
        }
        String []res=dimensions.split(" ");

        int rows, cols;
        rows=Integer.parseInt(res[0]);
        cols=Integer.parseInt(res[1]);
        boolean flag=inputValidator(new int[]{rows,cols});
        if(!flag){
            displayResult(null);
            return;
        }

        if(rows*cols != (res.length - 2)){
            displayResult(null);
            return;
        }
        int count=2;
        int[][] matrix = new int[rows][cols];
        for (int i = 0; i < rows; i++) {
            for(int j=0;j<cols;j++) {
                matrix[i][j] = Integer.parseInt((res[count]));
                count++;
            }

        }

        int [][]san= new int[rows][cols];
        san=computeSumOfNeighbours(matrix);
        displayResult(san);
    }

    //write logic to  validate the given input
    public boolean inputValidator(int[] input) {
        int row=input[0];
        int col=input[1];

        if(row<=1 || col<=1){
            flag=false;
            return false;
        }
        return true;
    }

    //write logic to find sum of neighbours of elements and return the result array
    public int[][] computeSumOfNeighbours(int[][] numbers) {


//        inputValidator(numbers);
        int row=numbers.length;
        int col=numbers[0].length;
        int []rowcol=new int[2];
//        rowcol[0]=row;
//        rowcol[1]=col;
//        inputValidator(rowcol);
        int[][] arr=new int[row][col];

        for(int i=0;i<row;i++){
            for(int j=0;j<col;j++){
                int res=0;
                if(i-1>=0){
                    res+=numbers[i-1][j];
                }
                if(j-1>=0){
                    res+=numbers[i][j-1];
                }
                if(i+1<row){
                    res+=numbers[i+1][j];
                }
                if(j+1<col){
                    res+=numbers[i][j+1];
                }
                if(i-1>=0 && j-1>=0){
                    res+=numbers[i-1][j-1];
                }
                if(i+1<row && j-1>=0){
                    res+=numbers[i+1][j-1];
                }
                if(i-1>=0 && j+1<col){
                    res+=numbers[i-1][j+1];
                }
                if(i+1<row && j+1<col){
                    res+=numbers[i+1][j+1];
                }

                arr[i][j]=res;
            }
        }

        return arr;
    }

    //write logic to print the result
    public void displayResult(int[][] sum) {
        if(!flag || sum==null){
            System.out.println("Give proper input");
            return;
        }
        for(int i=0;i<sum.length;i++){
            for(int j=0;j<sum[i].length;j++){

                System.out.print(sum[i][j]+" ");
            }
//                System.out.println();
        }
    }
}




