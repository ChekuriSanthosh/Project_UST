package com.stackroute.arrays;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

import static org.junit.jupiter.api.Assertions.assertEquals;


public class SumOfNeighboursAppTests {

    private ByteArrayOutputStream myOutStream;

    @BeforeEach
    public void setUp() {
        myOutStream = new ByteArrayOutputStream();
        System.setOut(new PrintStream(myOutStream));
    }

    @AfterEach
    public void tearDown() {
        myOutStream = null;
    }

    @Test
    public void given2DArrayThenShouldDisplay2DArrayWithRequiredSums() {
        String input = "3 3 1 2 3 4 5 6 7 8 9";
        String output = "11 19 13 23 40 27 17 31 19";
        ByteArrayInputStream myInputStream = new ByteArrayInputStream(input.getBytes());
        System.setIn(myInputStream);
        SumOfNeighbours.main(null);
        String actual = myOutStream.toString().trim().replaceAll(".*\n", "");
        String MSG1 = "SumOfNeighbours Should display a 2D Array with the Neighbours sum for Each elements in the Input Array";
        assertEquals(output, actual, MSG1);
    }

    @Test
    public void given2DArrayOfLesserDimensionThenShouldDisplayErrorMessage() {
        String input = "2 1";
        String output = "Give proper input";
        ByteArrayInputStream myInputStream = new ByteArrayInputStream(input.getBytes());
        System.setIn(myInputStream);
        SumOfNeighbours.main(null);
        String actual = myOutStream.toString().trim().replaceAll(".*\n", "");
        String MSG1 = "SumOfNeighbours Should display 'Give proper input' for the Input 2D Arrays of Lesser Dimension";
        assertEquals(output, actual, MSG1);
    }

    @Test
    public void given2DArrayOfZeroDimensionThenShouldDisplayErrorMessage() {
        String input = "4 0";
        String output = "Give proper input";
        ByteArrayInputStream myInputStream = new ByteArrayInputStream(input.getBytes());
        System.setIn(myInputStream);
        SumOfNeighbours.main(null);
        String actual = myOutStream.toString().trim().replaceAll(".*\n", "");
        String MSG1 = "SumOfNeighbours Should display 'Give proper input' for the Input 2D Arrays of Lesser Dimension";
        assertEquals(output, actual, MSG1);
    }

}
