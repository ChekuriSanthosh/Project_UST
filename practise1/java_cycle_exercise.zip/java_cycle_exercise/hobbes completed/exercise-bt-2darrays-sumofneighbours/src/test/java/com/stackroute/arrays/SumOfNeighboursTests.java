package com.stackroute.arrays;

import org.junit.jupiter.api.*;
import static org.junit.jupiter.api.Assertions.*;

public class SumOfNeighboursTests {
    private SumOfNeighbours sumOfNeighbours;
    private static final String MESSAGE = "Method Should return a 2D Array with Neighbours Sum for Each Elements in the Valid Input 2D Array";
    private static final String INPUT_VALIDATOR_MESSAGE = "check logic of your inputValidator method";
    @BeforeEach
    public void setUp() {
        sumOfNeighbours = new SumOfNeighbours();
    }

    @AfterEach
    public void tearDown() {
        sumOfNeighbours = null;
    }

    @Test
    public void given2DArrayOfValidDimensionThenReturn2DArrayWithSums() {
        int[][] input = {{1, 2, 3}, {4, 5, 6}, {7, 8, 9}};
        int[][] expected = {{11, 19, 13}, {23, 40, 27}, {17, 31, 19}};
        int[][] actual = sumOfNeighbours.computeSumOfNeighbours(input);
        assertArrayEquals(expected, actual, MESSAGE);
    }

    @Test
    public void given2DArrayOfValidDimensionWithNegativeIntegersThenReturn2DArrayWithSums() {
        int[][] input = {{1, -2, 3}, {4, 5, -6}, {-7, 8, 9}};
        int[][] expected = {{7, 7, -3}, {5, 10, 23}, {17, 5, 7}};
        assertArrayEquals(expected, sumOfNeighbours.computeSumOfNeighbours(input), MESSAGE);
    }

    @Test
    public void given2DArrayOfValidDimensionWithZeroThenReturn2DArrayWithSums() {
        int[][] input = {{1, 0, 3}, {-4, 5, 0}, {0, -1, 1}};
        int[][] expected = {{1, 5, 5}, {5, 0, 8}, {0, 2, 4}};
        assertArrayEquals(expected, sumOfNeighbours.computeSumOfNeighbours(input), MESSAGE);
    }

    @Test
    public void given2DArrayOfValidDimensionWithZerosThenReturn2DArrayWithSums() {
        int[][] input = {{0, 0}, {0, 0}};
        int[][] expected = {{0, 0}, {0, 0}};
        assertArrayEquals(expected, sumOfNeighbours.computeSumOfNeighbours(input), MESSAGE);
    }

    @Test
    public void givenArrayOfValidRowAndColumnSizeThenReturnTrue() {
        int[] input = {3,4};
        assertTrue(sumOfNeighbours.inputValidator(input),INPUT_VALIDATOR_MESSAGE);
    }
    @Test
    public void givenArrayOfInvalidRowAndColumnSizeThenReturnFalse() {
        int[] input = {-1,4};
        assertFalse(sumOfNeighbours.inputValidator(input),INPUT_VALIDATOR_MESSAGE);
    }


}