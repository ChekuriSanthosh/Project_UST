package com.stackroute.collections;

import java.util.ArrayList;
import java.util.List;

/*
 * This class contains methods for adding Fruits to a List and searching the fruits from the List
 */
public class FruitsListService {
    public static List<String> addFruitsToList(String fruitNames) {
        List<String> res=new ArrayList<>();
        List<String> caseres=new ArrayList<>();
        if(fruitNames==null || fruitNames.length()==0){
            return res;
        }
        String []fruits=fruitNames.split(",");
        for(int i=0;i<fruits.length;i++){
            if(fruits[i]==null || fruits[i]==""){
                return new ArrayList<String>();
            }

            String fruit=fruits[i].toLowerCase();
            if(!caseres.contains(fruit)){
                res.add(fruits[i]);
            }
            caseres.add(fruits[i].toLowerCase());
        }
        return res;
    }

    public static int searchFruitInList(List<String> fruitList, String searchFruit) {
        if(fruitList.contains(searchFruit)){
            return fruitList.indexOf(searchFruit);
        }
        return -1;
    }

    public static int searchFruitInListIgnoreCase(List<String> fruitList, String searchFruit) {
        for(int i=0;i<fruitList.size();i++){
            if(fruitList.get(i).toLowerCase().equals(searchFruit.toLowerCase())){
                return i;
            }
        }
        return -1;
    }

}