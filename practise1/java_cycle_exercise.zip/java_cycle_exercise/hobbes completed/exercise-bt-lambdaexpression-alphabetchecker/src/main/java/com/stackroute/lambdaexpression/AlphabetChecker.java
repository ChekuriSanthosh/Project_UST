package com.stackroute.lambdaexpression;

import java.util.Calendar;
import java.util.List;

public class AlphabetChecker {
    //write logic to find whether given string contains only alphabets or not
    public String checkAlphabets(List<String> inputList) {
        if(inputList==null || inputList.size()==0){
            return "Give proper input not empty list";
        }
        String Alphabets="abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
        for(String input:inputList){
            for(int i=0;i<input.length();i++){
                String index= Character.toString(input.charAt(i));
                if(!Alphabets.contains(index)){
                    return "Given list contains non alphabet strings";
                }
            }
        }
        return "Given list contains only alphabet strings";
    }
}
