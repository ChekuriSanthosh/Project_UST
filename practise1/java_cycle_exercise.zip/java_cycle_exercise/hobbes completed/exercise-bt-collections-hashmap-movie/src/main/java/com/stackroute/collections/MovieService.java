package com.stackroute.collections;

import java.time.LocalDate;
import java.util.*;

/*
This class contains a property called movieMap of type Map
This class contains methods for adding key-value pairs of Movie and its rating to HashMap and
various methods for accessing the keys and values based on some conditions
 */
public class MovieService {

    Map<Movie, Integer> movieMap=new LinkedHashMap<>();


    /**
     * Constructor to create movieMap as an empty  LinkedHashMap object
     */
    public MovieService() {
        Map<Movie,Integer> res=new LinkedHashMap<>();
        this.movieMap=res;
    }

    /*
    Returns the movieMap object
     */
    public Map<Movie, Integer> getMovieMap()
    {
        return movieMap;
    }

    /*
    Add key-value pairs of Movie-Integer type and returns Set of Map.Entry
     */
    public Set<Map.Entry<Movie, Integer>> addKeyValuePairsToMap(Movie movie, Integer rating) {
//        Set<Map.Entry<Movie,Integer>> s=new TreeSet<>();
        movieMap.put(movie,rating);
        Set<Map.Entry<Movie,Integer>>s= movieMap.entrySet();
        return s;
    }

    /*
    Return Set of movie names having rating greater than or equal to given rating
     */
    public List<String> getHigherRatedMovieNames(int rating) {
        List<String> res=new ArrayList<>();
        for(Movie key:movieMap.keySet()){
            if(movieMap.get(key)>=rating){
                res.add(key.getMovieName());
            }
        }
        return res;
    }

    /*
    Return Set of movie names belonging to specific genre
     */
    public List<String> getMovieNamesOfSpecificGenre(String genre) {
        List<String> res=new ArrayList<>();
        for(Movie key: movieMap.keySet()){
            if(Objects.equals(key.getGenre(), genre)){
                res.add(key.getMovieName());
            }
        }
        return res;
    }

   /*
   Return Set of movie names which are released after Specific releaseDate and having rating less than or equal to 3
    */

    public List<String> getMovieNamesReleasedAfterSpecificDateAndRatingLesserThanThree(LocalDate releaseDate) {
        List<String> res=new ArrayList<>();
        for(Movie key:movieMap.keySet()){
            LocalDate san=key.getReleaseDate();
            if(san.compareTo(releaseDate)>0 && movieMap.get(key)<=3){
                res.add(key.getMovieName());
            }
        }
        return res;
    }

    /*
    Return set of movies sorted by release dates in ascending order.
    Hint: Use TreeMap
     */
    public List<Movie> getSortedMovieListByReleaseDate() {
//        Map<Movie,Integer> res=new TreeMap<>(Movie::compareTo);
//        for(Movie key:movieMap.keySet()){
//            res.put(key,movieMap.get(key));
//        }
//        List<Movie>ans=new ArrayList<>();
//        for(Movie key:res.keySet()){
//            ans.add(key);
//        }
//        return ans;
        List<Map.Entry<Movie, Integer>> entryList = new ArrayList<>(movieMap.entrySet());
        entryList.sort(Map.Entry.comparingByKey(Comparator.comparing(Movie::getReleaseDate)));
        List<Movie> sortedMap = new ArrayList<>();
        for (Map.Entry<Movie, Integer> entry : entryList) {
            sortedMap.add(entry.getKey());
        }

        return sortedMap;
    }

    /*
   Return set of movies sorted by rating.
   Hint: Use Comparator and LinkedHashMap
    */
    public Map<Movie, Integer> getSortedMovieListByRating() {

        List<Map.Entry<Movie,Integer>> entryList=new ArrayList<>(movieMap.entrySet());
        entryList.sort(Map.Entry.comparingByValue());
        Map<Movie,Integer> sortedMap = new LinkedHashMap<>();
        for (Map.Entry<Movie, Integer> entry : entryList) {
            sortedMap.put(entry.getKey(),entry.getValue());
            System.out.println(entry.getKey());
        }

        return sortedMap;
    }
}
