package com.stackroute.fileio;

import java.io.*;
import java.util.*;

public class RemoveDuplicateLines {
    //write logic to read data from input.txt and  write result to output.txt
    public void removeDuplicateLines() throws IOException {
        InputStream input;
        Set<String> res=new LinkedHashSet<>();
        String ans="";
        try {
            input=new FileInputStream("input.txt");
            Scanner scanner=new Scanner(input);
            while (scanner.hasNextLine()){
                String r=scanner.nextLine();
                res.add(r);
            }
            System.out.println(res);

        }catch (IOException e){
            throw new IOException(e.getMessage());
        }

        for(String s:res){
            ans+=(s+'\n');
        }
        try {
            Writer output=new FileWriter("output.txt");
            output.write(ans);
            output.close();


        }catch (IOException e){
            throw new IOException(e);
        }

    }
}
