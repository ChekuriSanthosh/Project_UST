package org.model;

public enum Size {
    EXTRA_SMALL, SMALL, MEDIUM, LARGE, EXTRA_LARGE;
}
