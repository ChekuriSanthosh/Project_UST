package org.exception;

public class DuplicateProductException extends Exception{
    public DuplicateProductException(String message) {
        super(message);
    }
}
