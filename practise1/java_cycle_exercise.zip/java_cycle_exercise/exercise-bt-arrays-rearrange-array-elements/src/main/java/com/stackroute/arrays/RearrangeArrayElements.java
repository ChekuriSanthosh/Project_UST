package com.stackroute.arrays;

import java.util.Scanner;

public class RearrangeArrayElements {
    public static void main(String[] args) {
        new RearrangeArrayElements().inputAcceptor();
    }

    //write logic to get inputs from user and send inputs for validation
    public void inputAcceptor() {
        Scanner scanner=new Scanner(System.in);
        String res=scanner.nextLine();
        String []temp=res.split(" ");
        int n=Integer.parseInt(temp[0]);
        boolean validsize=inputArraySizeValidator(n);
        if(!validsize){
            System.out.println("Give proper input");
            return;
        }
        int []res1=new int[n];
        for(int i=1;i< temp.length;i++){
            res1[i-1]=Integer.parseInt(temp[i]);
        }
        if(!inputArrayValidator(res1)){
            System.out.println("Give proper input");
            return;
        }
        int []ans=computeRearrangedArray(res1);
        displayResult(ans);

    }

    //write logic to validate the given array size is valid or not
    public boolean inputArraySizeValidator(int size) {
        if(size>=1){
            return true;
        }
        return false;
    }

    //write logic to validate the given input array is sorted or not
    public boolean inputArrayValidator(int[] input) {
        boolean flag=true;
        for(int i=1;i<input.length;i++){
            if(input[i-1]>input[i]){
                return false;
            }
        }
        return true;
    }

    //write logic to rearrange elements of array and return the result array
    public int[] computeRearrangedArray(int[] inputArray) {
        if(inputArray==null || inputArray.length==0){
            return null;
        }
        boolean flag=true;
        int []arr=new int[inputArray.length];
        int s=0,e=inputArray.length-1,i=0;
        while(s<=e){
            if(flag){
                arr[i]=inputArray[e];
                e--;
                i++;
            }else{
                arr[i]=inputArray[s];
                s++;
                i++;
            }
            flag=!flag;
        }
        return arr;
    }

    //write logic to print the result
    public void displayResult(int[] outputArray) {
        for(int i=0;i<outputArray.length;i++){
            System.out.print(outputArray[i]);
            if(i!=outputArray.length-1){
                System.out.print(" ");
            }
        }
    }
}
