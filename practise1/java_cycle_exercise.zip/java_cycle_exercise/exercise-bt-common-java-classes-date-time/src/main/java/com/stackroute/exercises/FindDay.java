package com.stackroute.exercises;


import java.time.LocalDate;

public class FindDay {

    public String validMonth(int month){
        if(month<1 || month>12){
            return "Give month in range";
        }
        return "";
    }
    public String validDay(int day){
        if(day<1 || day>31){
            return "Give day in range";
        }
        return "";
    }
    public String validYear(int year){
        if(year<2000 || year>3000){
            return "Give year in range";
        }
        return "";
    }
    //write logic to find day of the date and return result
    public String findDay(int month, int day, int year) {
        String res2=validDay(day);
        String res1=validMonth(month);
        String res3=validYear(year);
        if((res3+res2+res1).length()>0){
            return res1+res2+res3;
        }

        LocalDate date=LocalDate.of(year,month,day);
        String []res={"MONDAY","TUESDAY","WEDNESDAY","THURSDAY","FRIDAY","SATURDAY","SUNDAY"};
        return date.getDayOfWeek().toString();
    }
}
